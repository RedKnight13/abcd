var attempt = 5; 
function validate(){
var username = document.getElementById("demo-email").value;
var password = document.getElementById("demo-pass").value;
if ( username == "athil@gmail.com" && password == "athil@123"){
alert ("Login successfully");

return false;
}
else{
attempt --;
alert("You have left "+attempt+" attempt;");
if( attempt == 0){
document.getElementById("demo-email").disabled = true;
document.getElementById("demo-pass").disabled = true;
document.getElementById("submit").disabled = true;
return false;
}
}
}